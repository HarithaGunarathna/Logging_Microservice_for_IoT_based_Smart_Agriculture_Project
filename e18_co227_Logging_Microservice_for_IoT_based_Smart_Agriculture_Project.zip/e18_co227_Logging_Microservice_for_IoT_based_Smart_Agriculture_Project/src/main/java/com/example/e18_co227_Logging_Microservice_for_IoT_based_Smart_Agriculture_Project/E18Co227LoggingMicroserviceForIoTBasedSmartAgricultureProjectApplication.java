package com.example.e18_co227_Logging_Microservice_for_IoT_based_Smart_Agriculture_Project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class E18Co227LoggingMicroserviceForIoTBasedSmartAgricultureProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(E18Co227LoggingMicroserviceForIoTBasedSmartAgricultureProjectApplication.class, args);
	}

}
