package com.example.e18_co227_Logging_Microservice_for_IoT_based_Smart_Agriculture_Project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class E18Co227LoggingMicroserviceForIoTBasedSmartAgricultureProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
