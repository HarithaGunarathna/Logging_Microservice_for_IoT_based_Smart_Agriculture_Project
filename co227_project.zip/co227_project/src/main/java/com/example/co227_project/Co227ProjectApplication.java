package com.example.co227_project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Co227ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(Co227ProjectApplication.class, args);
	}

}
